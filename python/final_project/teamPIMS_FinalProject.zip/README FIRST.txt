Greetings user!

This zip file contains one .py file containing the entire program and
a folder containing sound waves which are musical tones ABCDEFG.

You do not have to move anything anywhere

Open the file from the extracted folder and run the .py file from that location.

Thank you and enjoy!

-Team PIMS